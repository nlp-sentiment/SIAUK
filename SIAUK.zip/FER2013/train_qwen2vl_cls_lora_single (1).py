import os
import math
import json
import random
from typing import List, Tuple, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from PIL import Image
from tqdm import tqdm

from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration
from peft import LoraConfig, get_peft_model

from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt


# =========================
# Config (稳定版默认参数)
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"

DATA_ROOT = "/gemini/code/images_fer_80_224"
TRAIN_DIR = os.path.join(DATA_ROOT, "Training")
VAL_DIR   = os.path.join(DATA_ROOT, "PublicTest")
TEST_DIR  = os.path.join(DATA_ROOT, "PrivateTest")

OUT_DIR = "/gemini/code/outputs/qwen2vl_cls_lora_single"
os.makedirs(OUT_DIR, exist_ok=True)

SEED = 42

NUM_EPOCHS = 5
BATCH_SIZE = 1
GRAD_ACCUM_STEPS = 8
NUM_WORKERS = 2

# 你提出的更稳 LR（已采纳）
LR_HEAD = 2.5e-5
LR_LORA = 5e-5
WEIGHT_DECAY = 0.01
WARMUP_RATIO = 0.03

MAX_TEXT_LEN = 128
PRINT_EVERY = 50

# ✅ 推荐：启用 AMP，但优先 bf16（更稳）
USE_AMP = True
USE_GRAD_CHECKPOINT = True
CLIP_GRAD_NORM = 1.0

# LoRA
LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05
LORA_TARGET_MODULES = ["q_proj", "k_proj"]

# ✅ 关键：必须包含 <|image_pad|>
PROMPT_TEMPLATE = (
    "<|image_pad|> This is a facial expression recognition task.\n\n"
    "Carefully analyze the person's facial muscles and visual cues, including:\n"
    "- Eyes (openness, tension, gaze)\n"
    "- Eyebrows (raised, lowered, furrowed)\n"
    "- Mouth and lips (smile, frown, openness)\n"
    "- Cheeks and nasolabial area\n\n"
    "You may reason using Facial Action Units (AUs), for example:\n"
    "- AU06 (cheek raiser)\n"
    "- AU12 (lip corner puller)\n"
    "- AU04 (brow lowerer)\n"
    "- AU01/02 (inner/outer brow raiser)\n"
    "- AU15 (lip corner depressor)\n\n"
    "Based on these visual signals, determine the most appropriate emotion.\n\n"
    "The possible emotion labels are: {labels}.\n\n"
    "Answer with only ONE emotion label from the list above."
)

# =========================
# Utils
# =========================
def set_seed(seed: int):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def is_valid_class_dir(name: str) -> bool:
    if name.startswith("."):
        return False
    if "ipynb_checkpoints" in name:
        return False
    return True


def list_images_and_labels(root_dir: str) -> Tuple[List[str], List[int], List[str]]:
    all_dirs = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
    class_names = sorted([d for d in all_dirs if is_valid_class_dir(d)])

    if len(class_names) == 0:
        raise RuntimeError(f"No valid class folders found in: {root_dir}")

    class_to_idx = {c: i for i, c in enumerate(class_names)}

    paths, labels = [], []
    for c in class_names:
        cdir = os.path.join(root_dir, c)
        for fn in os.listdir(cdir):
            if fn.lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".webp")):
                paths.append(os.path.join(cdir, fn))
                labels.append(class_to_idx[c])

    return paths, labels, class_names


class FERFolderDataset(Dataset):
    def __init__(self, root_dir: str, expected_classes: List[str] = None):
        self.paths, self.labels, self.class_names = list_images_and_labels(root_dir)

        if expected_classes is not None:
            if self.class_names != expected_classes:
                raise RuntimeError(
                    f"[CLASS MISMATCH] {root_dir}\n"
                    f"expected: {expected_classes}\n"
                    f"got     : {self.class_names}"
                )

        print(f"📊 Loaded {len(self.paths)} samples from {root_dir}")

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx: int):
        img = Image.open(self.paths[idx]).convert("RGB")
        label = self.labels[idx]
        return img, label


def build_processor_inputs(processor: Qwen2VLProcessor, images: List[Image.Image], text: List[str]) -> Dict[str, torch.Tensor]:
    inputs = processor(
        text=text,
        images=images,
        padding=True,
        truncation=True,
        max_length=MAX_TEXT_LEN,
        return_tensors="pt",
    )
    return inputs


def collate_fn(batch, processor, class_names):
    images = [x[0] for x in batch]
    labels = torch.tensor([x[1] for x in batch], dtype=torch.long)

    label_str = ", ".join(class_names)
    prompt = PROMPT_TEMPLATE.format(labels=label_str)
    texts = [prompt] * len(images)

    inputs = processor(
        text=texts,
        images=images,
        padding=True,
        truncation=True,
        max_length=MAX_TEXT_LEN,
        return_tensors="pt",
    )

    inputs["labels_cls"] = labels
    return inputs


def get_linear_warmup_scheduler(optimizer, warmup_steps: int, total_steps: int):
    def lr_lambda(step: int):
        if step < warmup_steps:
            return float(step) / float(max(1, warmup_steps))
        return max(0.0, float(total_steps - step) / float(max(1, total_steps - warmup_steps)))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def plot_confusion_matrix(y_true, y_pred, class_names: List[str], save_path: str, title: str):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    plt.imshow(cm, interpolation="nearest")
    plt.title(title)
    plt.colorbar()
    ticks = range(len(class_names))
    plt.xticks(ticks, class_names, rotation=45, ha="right")
    plt.yticks(ticks, class_names)

    thresh = cm.max() * 0.6 if cm.max() > 0 else 0.5
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            val = cm[i, j]
            plt.text(j, i, str(val), ha="center", va="center",
                     color="white" if val > thresh else "black")

    plt.ylabel("True")
    plt.xlabel("Pred")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()


# =========================
# Model wrapper (稳定版)
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base: Qwen2VLForConditionalGeneration, num_classes: int, image_token_id: int):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id  # ✅ 关键：用于定位图像 token

        hidden = base.config.hidden_size
        self.classifier = nn.Linear(hidden, num_classes)
        nn.init.normal_(self.classifier.weight, std=0.02)
        nn.init.zeros_(self.classifier.bias)

    def forward(self, **kwargs):
        labels_cls = kwargs.pop("labels_cls", None)
        clean = {k: v for k, v in kwargs.items() if v is not None}

        out = self.base(**clean, output_hidden_states=True, return_dict=True)
        last_h = out.hidden_states[-1]  # [B, T, H]

        # ✅ Visual-token mean pooling：只池化图像 token 的位置
        input_ids = clean.get("input_ids", None)
        if input_ids is None:
            # fallback：没有 input_ids 就退回 last token
            pooled = last_h[:, -1, :]
        else:
            img_mask = (input_ids == self.image_token_id)  # [B, T] bool
            if img_mask.any():
                mask = img_mask.unsqueeze(-1).to(dtype=last_h.dtype)  # [B,T,1]
                denom = mask.sum(dim=1).clamp(min=1.0)
                pooled = (last_h * mask).sum(dim=1) / denom
            else:
                # fallback：如果没找到 image token，就退回 attention_mask mean pooling
                attn = clean.get("attention_mask", None)
                if attn is None:
                    pooled = last_h[:, -1, :]
                else:
                    mask = attn.unsqueeze(-1).to(dtype=last_h.dtype)
                    denom = mask.sum(dim=1).clamp(min=1.0)
                    pooled = (last_h * mask).sum(dim=1) / denom

        pooled = pooled.to(self.classifier.weight.dtype)
        logits = self.classifier(pooled)

        if labels_cls is None:
            return logits

        loss = F.cross_entropy(logits, labels_cls)
        return logits, loss

def get_amp_dtype(device: torch.device):
    # 优先 bf16：更稳
    if device.type == "cuda" and torch.cuda.is_available():
        try:
            if torch.cuda.is_bf16_supported():
                return torch.bfloat16
        except Exception:
            pass
    return torch.float16


@torch.no_grad()
def evaluate(model: nn.Module, loader: DataLoader, device: torch.device, class_names: List[str], split_name: str,
             use_amp: bool, amp_dtype: torch.dtype):
    model.eval()
    all_y, all_p = [], []
    total_loss = 0.0
    n = 0

    for batch in tqdm(loader, desc=f"Eval[{split_name}]"):
        labels = batch.pop("labels_cls").to(device)
        for k in list(batch.keys()):
            batch[k] = batch[k].to(device)

        if use_amp and device.type == "cuda":
            with torch.cuda.amp.autocast(dtype=amp_dtype):
                logits, loss = model(labels_cls=labels, **batch)
        else:
            logits, loss = model(labels_cls=labels, **batch)

        total_loss += float(loss.item()) * labels.size(0)
        n += labels.size(0)

        pred = torch.argmax(logits, dim=-1)
        all_y.extend(labels.cpu().tolist())
        all_p.extend(pred.cpu().tolist())

    acc = accuracy_score(all_y, all_p)
    f1 = f1_score(all_y, all_p, average="macro")
    avg_loss = total_loss / max(n, 1)
    return avg_loss, acc, f1, all_y, all_p


# =========================
# Main
# =========================
def main():
    set_seed(SEED)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"✅ device: {device}")

    assert os.path.isdir(MODEL_PATH), f"MODEL_PATH not found: {MODEL_PATH}"
    assert os.path.isdir(TRAIN_DIR), f"TRAIN_DIR not found: {TRAIN_DIR}"
    assert os.path.isdir(VAL_DIR), f"VAL_DIR not found: {VAL_DIR}"
    assert os.path.isdir(TEST_DIR), f"TEST_DIR not found: {TEST_DIR}"

    train_ds = FERFolderDataset(TRAIN_DIR)
    class_names = train_ds.class_names
    num_classes = len(class_names)
    print(f"✅ num_classes={num_classes}, classes={class_names}")

    val_ds = FERFolderDataset(VAL_DIR, expected_classes=class_names)
    test_ds = FERFolderDataset(TEST_DIR, expected_classes=class_names)

    print("🚀 Loading processor & base model...")
    processor = Qwen2VLProcessor.from_pretrained(MODEL_PATH, local_files_only=True)
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    # ✅ base 用低内存加载
    amp_dtype = get_amp_dtype(device)
    base_dtype = amp_dtype if (USE_AMP and device.type == "cuda") else torch.float32

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=base_dtype,
        local_files_only=True,
        low_cpu_mem_usage=True,
    )

    if USE_GRAD_CHECKPOINT:
        base.gradient_checkpointing_enable()
        base.config.use_cache = False

    for p in base.parameters():
        p.requires_grad = False

    print("🧩 Applying LoRA...")
    lora_cfg = LoraConfig(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        target_modules=LORA_TARGET_MODULES,
        task_type="CAUSAL_LM",
    )
    base = get_peft_model(base, lora_cfg)

    model = Qwen2VLClassifier(base, num_classes=num_classes, image_token_id=image_token_id).to(device)

    # ✅ 让分类头 dtype 与 base 一致（彻底避免 dtype mismatch）
    model.classifier = model.classifier.to(dtype=base_dtype, device=device)

    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"🧮 Trainable params: {trainable:,} / {total:,} ({100*trainable/total:.4f}%)")
    print(f"✅ AMP={USE_AMP}, amp_dtype={amp_dtype}, base_dtype={base_dtype}")

    train_loader = DataLoader(
        train_ds, batch_size=BATCH_SIZE, shuffle=True,
        num_workers=NUM_WORKERS, pin_memory=True,
       collate_fn=lambda b: collate_fn(b, processor, class_names),
    )
    val_loader = DataLoader(
        val_ds, batch_size=BATCH_SIZE, shuffle=False,
        num_workers=NUM_WORKERS, pin_memory=True,
        collate_fn=lambda b: collate_fn(b, processor, class_names),
    )
    test_loader = DataLoader(
        test_ds, batch_size=BATCH_SIZE, shuffle=False,
        num_workers=NUM_WORKERS, pin_memory=True,
        collate_fn=lambda b: collate_fn(b, processor, class_names),
    )

    head_params, lora_params = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if name.startswith("classifier."):
            head_params.append(p)
        elif "lora_" in name:
            lora_params.append(p)

    if len(head_params) == 0:
        raise RuntimeError("No head params found.")
    if len(lora_params) == 0:
        raise RuntimeError("No lora params found. Check target_modules.")

    optim = torch.optim.AdamW(
        [
            {"params": head_params, "lr": LR_HEAD, "weight_decay": WEIGHT_DECAY},
            {"params": lora_params, "lr": LR_LORA, "weight_decay": WEIGHT_DECAY},
        ],
        betas=(0.9, 0.999),
        eps=1e-8,
    )

    total_steps = math.ceil(len(train_loader) / GRAD_ACCUM_STEPS) * NUM_EPOCHS
    warmup_steps = int(total_steps * WARMUP_RATIO)
    sched = get_linear_warmup_scheduler(optim, warmup_steps, total_steps)

    # ✅ GradScaler：只有 fp16 才需要，bf16 不需要
    use_scaler = (USE_AMP and device.type == "cuda" and amp_dtype == torch.float16)
    scaler = torch.cuda.amp.GradScaler(enabled=use_scaler)

    best_val_acc = -1.0

    for epoch in range(NUM_EPOCHS):
        model.train()
        optim.zero_grad(set_to_none=True)

        running_loss = 0.0
        seen = 0

        pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Epoch {epoch+1}/{NUM_EPOCHS}")
        for it, batch in pbar:
            labels = batch.pop("labels_cls").to(device)
            for k in list(batch.keys()):
                batch[k] = batch[k].to(device)

            # forward
            if USE_AMP and device.type == "cuda":
                with torch.cuda.amp.autocast(dtype=amp_dtype):
                    logits = model(**batch)          # 👈 只拿 logits
                    loss = F.cross_entropy(
                        logits,
                        labels,
                        label_smoothing=0.1
                    )
            else:
                logits = model(**batch)
                loss = F.cross_entropy(
                    logits,
                    labels,
                    label_smoothing=0.1
                )

            # ✅ NaN/Inf 防护：发现就跳过（彻底避免参数被污染）
            if not torch.isfinite(loss):
                optim.zero_grad(set_to_none=True)
                pbar.set_postfix(loss="NaN_skip", lr=f"{sched.get_last_lr()[0]:.2e}")
                continue

            loss = loss / GRAD_ACCUM_STEPS

            # backward
            if use_scaler:
                scaler.scale(loss).backward()
            else:
                loss.backward()

            running_loss += float(loss.item()) * labels.size(0)
            seen += labels.size(0)

            if (it + 1) % GRAD_ACCUM_STEPS == 0:
                if use_scaler:
                    scaler.unscale_(optim)
                torch.nn.utils.clip_grad_norm_(model.parameters(), CLIP_GRAD_NORM)

                if use_scaler:
                    scaler.step(optim)
                    scaler.update()
                else:
                    optim.step()

                sched.step()
                optim.zero_grad(set_to_none=True)

            if (it + 1) % PRINT_EVERY == 0:
                avg_loss = running_loss / max(seen, 1)
                pbar.set_postfix(loss=f"{avg_loss:.4f}", lr=f"{sched.get_last_lr()[0]:.2e}")

        # ✅ 验证阶段也用 AMP（保持 dtype 一致，彻底不炸）
        val_loss, val_acc, val_f1, vy, vp = evaluate(
            model, val_loader, device, class_names, "PublicTest",
            use_amp=(USE_AMP and device.type == "cuda"), amp_dtype=amp_dtype
        )
        print(f"✅ Epoch {epoch+1}: Val loss={val_loss:.4f}, acc={val_acc:.4f}, f1={val_f1:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            ckpt_path = os.path.join(OUT_DIR, "best.pt")
            torch.save(
                {
                    "epoch": epoch + 1,
                    "best_val_acc": best_val_acc,
                    "model_state": model.state_dict(),
                    "class_names": class_names,
                },
                ckpt_path,
            )
            print(f"💾 Saved best checkpoint -> {ckpt_path}")

            cm_path = os.path.join(OUT_DIR, "confusion_val.png")
            plot_confusion_matrix(vy, vp, class_names, cm_path, "Confusion Matrix (PublicTest)")
            print(f"🖼️ Saved val confusion matrix -> {cm_path}")

    ckpt_path = os.path.join(OUT_DIR, "best.pt")
    if os.path.isfile(ckpt_path):
        ckpt = torch.load(ckpt_path, map_location="cpu")
        model.load_state_dict(ckpt["model_state"], strict=True)
        model.to(device)
        print(f"✅ Loaded best checkpoint for final test: {ckpt_path}")

    test_loss, test_acc, test_f1, ty, tp = evaluate(
        model, test_loader, device, class_names, "PrivateTest",
        use_amp=(USE_AMP and device.type == "cuda"), amp_dtype=amp_dtype
    )
    print(f"🎯 Final Test: loss={test_loss:.4f}, acc={test_acc:.4f}, f1={test_f1:.4f}")

    cm_path = os.path.join(OUT_DIR, "confusion_test.png")
    plot_confusion_matrix(ty, tp, class_names, cm_path, "Confusion Matrix (PrivateTest)")
    print(f"🖼️ Saved test confusion matrix -> {cm_path}")

    report = classification_report(ty, tp, target_names=class_names, digits=4)
    report_path = os.path.join(OUT_DIR, "classification_report_test.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"📄 Saved test report -> {report_path}")

    summary = {
        "best_val_acc": best_val_acc,
        "test_acc": test_acc,
        "test_f1_macro": test_f1,
        "lr_head": LR_HEAD,
        "lr_lora": LR_LORA,
        "grad_accum": GRAD_ACCUM_STEPS,
        "batch_size": BATCH_SIZE,
        "epochs": NUM_EPOCHS,
        "use_amp": USE_AMP,
        "amp_dtype": str(amp_dtype),
        "use_grad_checkpoint": USE_GRAD_CHECKPOINT,
        "classes": class_names,
    }
    with open(os.path.join(OUT_DIR, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"✅ Done. Outputs saved in: {OUT_DIR}")


if __name__ == "__main__":
    main()
