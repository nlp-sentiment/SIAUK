import os
import json
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration
from peft import LoraConfig, get_peft_model
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
from PIL import Image
from tqdm import tqdm

# =========================
# Paths
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"
CKPT_PATH  = "/gemini/code/outputs/qwen2vl_cls_lora_single/best.pt"
TEST_DIR   = "/gemini/code/images_fer_80_224/PrivateTest"
OUT_DIR    = "/gemini/code/outputs/qwen2vl_cls_lora_single"
os.makedirs(OUT_DIR, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =========================
# Prompt (MUST match training)
# =========================
PROMPT_TEMPLATE = (
    "<|image_pad|> This is a facial expression recognition task.\n\n"
    "Carefully analyze the person's facial muscles and visual cues.\n\n"
    "The possible emotion labels are: {labels}.\n\n"
    "Answer with only ONE emotion label."
)

# =========================
# Dataset
# =========================
class FERDataset(Dataset):
    def __init__(self, root, class_names):
        self.samples = []
        for i, c in enumerate(class_names):
            cls_dir = os.path.join(root, c)
            for fn in os.listdir(cls_dir):
                if fn.lower().endswith((".jpg", ".png", ".jpeg", ".bmp", ".webp")):
                    self.samples.append((os.path.join(cls_dir, fn), i))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        return img, label

# =========================
# ✅ 关键：评测用 collate_fn（修复 PIL.Image 报错）
# =========================
def eval_collate_fn(batch):
    imgs = [x[0] for x in batch]  # List[PIL.Image]
    labels = torch.tensor([x[1] for x in batch], dtype=torch.long)
    return imgs, labels

# =========================
# Confusion matrix
# =========================
def save_confusion_matrix(y_true, y_pred, class_names, save_path):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    plt.imshow(cm)
    plt.colorbar()
    plt.xticks(range(len(class_names)), class_names, rotation=45, ha="right")
    plt.yticks(range(len(class_names)), class_names)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()

# =========================
# Model wrapper (与训练一致)
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base, num_classes, image_token_id):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id
        self.classifier = nn.Linear(base.config.hidden_size, num_classes)

    def forward(self, **kwargs):
        out = self.base(**kwargs, output_hidden_states=True, return_dict=True)
        last_hidden = out.hidden_states[-1]  # [B, T, H]

        input_ids = kwargs["input_ids"]
        img_mask = (input_ids == self.image_token_id).unsqueeze(-1)  # [B,T,1]
        pooled = (last_hidden * img_mask).sum(1) / img_mask.sum(1).clamp(min=1)

        return self.classifier(pooled)

# =========================
# Main
# =========================
def main():
    print("🚀 Loading checkpoint...")
    ckpt = torch.load(CKPT_PATH, map_location="cpu")
    class_names = ckpt["class_names"]
    num_classes = len(class_names)

    processor = Qwen2VLProcessor.from_pretrained(
        MODEL_PATH, local_files_only=True
    )
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.bfloat16 if DEVICE.type == "cuda" else torch.float32,
        local_files_only=True,
        low_cpu_mem_usage=True,
    )

    # ===== LoRA (与训练完全一致) =====
    lora_cfg = LoraConfig(
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        task_type="CAUSAL_LM",
    )
    base = get_peft_model(base, lora_cfg)

    model = Qwen2VLClassifier(base, num_classes, image_token_id).to(DEVICE)
    model.load_state_dict(ckpt["model_state"], strict=True)
    model.eval()

    dataset = FERDataset(TEST_DIR, class_names)
    loader = DataLoader(
        dataset,
        batch_size=8,
        shuffle=False,
        num_workers=0,          # ✅ 必须为 0
        collate_fn=eval_collate_fn
    )

    y_true, y_pred = [], []

    print("🧪 Evaluating on PrivateTest...")
    for imgs, labels in tqdm(loader):
        prompt = PROMPT_TEMPLATE.format(labels=", ".join(class_names))
        inputs = processor(
            text=[prompt] * len(imgs),
            images=imgs,
            padding=True,
            return_tensors="pt"
        )
        inputs = {k: v.to(DEVICE) for k, v in inputs.items()}

        with torch.no_grad(), torch.cuda.amp.autocast(
            enabled=(DEVICE.type == "cuda"), dtype=torch.bfloat16
        ):
            logits = model(**inputs)

        preds = logits.argmax(dim=-1).cpu().tolist()
        y_true.extend(labels.tolist())
        y_pred.extend(preds)

    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average="macro")

    print(f"🎯 PrivateTest acc={acc:.4f}, f1={f1:.4f}")

    # =========================
    # Save outputs
    # =========================
    save_confusion_matrix(
        y_true, y_pred, class_names,
        os.path.join(OUT_DIR, "confusion_test.png")
    )

    report = classification_report(
        y_true, y_pred, target_names=class_names, digits=4
    )
    with open(os.path.join(OUT_DIR, "classification_report_test.txt"), "w") as f:
        f.write(report)

    with open(os.path.join(OUT_DIR, "summary.json"), "w") as f:
        json.dump(
            {
                "test_acc": acc,
                "test_f1_macro": f1,
                "num_samples": len(y_true),
            },
            f,
            indent=2
        )

    print("✅ All evaluation files saved successfully!")

if __name__ == "__main__":
    main()
