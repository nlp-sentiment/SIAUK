import os
import math
import json
import random
from typing import List, Tuple, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from PIL import Image
from tqdm import tqdm

from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration

from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt


# =========================
# Config
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"

DATA_ROOT = "/gemini/code/images_fer_80_224"
TRAIN_DIR = os.path.join(DATA_ROOT, "Training")
VAL_DIR   = os.path.join(DATA_ROOT, "PublicTest")
TEST_DIR  = os.path.join(DATA_ROOT, "PrivateTest")

OUT_DIR = "/gemini/code/outputs/qwen2vl_cls_no_lora_no_prompt"
os.makedirs(OUT_DIR, exist_ok=True)

SEED = 42

NUM_EPOCHS = 5
BATCH_SIZE = 1
GRAD_ACCUM_STEPS = 8
NUM_WORKERS = 2

LR_HEAD = 1e-4
WEIGHT_DECAY = 0.01
WARMUP_RATIO = 0.03

MAX_TEXT_LEN = 128
PRINT_EVERY = 50

USE_AMP = True
USE_GRAD_CHECKPOINT = True
CLIP_GRAD_NORM = 1.0

# 🚫 无指令 Prompt（严格 w/o instruction）
PROMPT_TEMPLATE = "<|image_pad|>"


# =========================
# Utils
# =========================
def set_seed(seed: int):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def is_valid_class_dir(name: str) -> bool:
    if name.startswith("."):
        return False
    if "ipynb_checkpoints" in name:
        return False
    return True


def list_images_and_labels(root_dir: str) -> Tuple[List[str], List[int], List[str]]:
    class_names = sorted([
        d for d in os.listdir(root_dir)
        if os.path.isdir(os.path.join(root_dir, d)) and is_valid_class_dir(d)
    ])
    class_to_idx = {c: i for i, c in enumerate(class_names)}

    paths, labels = [], []
    for c in class_names:
        for fn in os.listdir(os.path.join(root_dir, c)):
            if fn.lower().endswith((".jpg", ".png", ".jpeg", ".bmp", ".webp")):
                paths.append(os.path.join(root_dir, c, fn))
                labels.append(class_to_idx[c])

    print(f"📊 Loaded {len(paths)} samples from {root_dir}")
    return paths, labels, class_names


class FERFolderDataset(Dataset):
    def __init__(self, root_dir: str, expected_classes: List[str] = None):
        self.paths, self.labels, self.class_names = list_images_and_labels(root_dir)

        if expected_classes is not None and self.class_names != expected_classes:
            raise RuntimeError("Class mismatch across splits")

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        img = Image.open(self.paths[idx]).convert("RGB")
        return img, self.labels[idx]


def collate_fn(batch, processor):
    images, texts, labels = [], [], []

    for img, lab in batch:
        images.append(img)
        texts.append(PROMPT_TEMPLATE)
        labels.append(lab)

    inputs = processor(
        images=images,
        text=texts,
        padding=True,
        truncation=True,
        return_tensors="pt",
    )

    inputs["labels_cls"] = torch.tensor(labels, dtype=torch.long)
    return inputs


def get_amp_dtype(device):
    if device.type == "cuda" and torch.cuda.is_bf16_supported():
        return torch.bfloat16
    return torch.float16


def get_scheduler(optimizer, warmup_steps, total_steps):
    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(1, warmup_steps)
        return max(0.0, (total_steps - step) / max(1, total_steps - warmup_steps))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# =========================
# Model
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base, num_classes, image_token_id):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id
        self.classifier = nn.Linear(base.config.hidden_size, num_classes)

    def forward(self, **kwargs):
        labels = kwargs.pop("labels_cls", None)
        out = self.base(**kwargs, output_hidden_states=True, return_dict=True)
        hidden = out.hidden_states[-1]

        input_ids = kwargs["input_ids"]
        mask = (input_ids == self.image_token_id).unsqueeze(-1).to(hidden.dtype)
        pooled = (hidden * mask).sum(1) / mask.sum(1).clamp(min=1.0)

        pooled = pooled.to(self.classifier.weight.dtype)
        logits = self.classifier(pooled)

        if labels is None:
            return logits
        return logits, F.cross_entropy(logits, labels)


@torch.no_grad()
def evaluate(model, loader, device, amp_dtype):
    model.eval()
    ys, ps = [], []

    for batch in loader:
        labels = batch.pop("labels_cls").to(device)
        batch = {k: v.to(device) for k, v in batch.items()}

        with torch.cuda.amp.autocast(dtype=amp_dtype, enabled=device.type=="cuda"):
            logits = model(**batch)

        preds = logits.argmax(dim=-1)
        ys.extend(labels.cpu().tolist())
        ps.extend(preds.cpu().tolist())

    return accuracy_score(ys, ps), f1_score(ys, ps, average="macro"), ys, ps


# =========================
# Main
# =========================
def main():
    set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_ds = FERFolderDataset(TRAIN_DIR)
    class_names = train_ds.class_names
    val_ds = FERFolderDataset(VAL_DIR, class_names)
    test_ds = FERFolderDataset(TEST_DIR, class_names)

    processor = Qwen2VLProcessor.from_pretrained(MODEL_PATH, local_files_only=True)
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    amp_dtype = get_amp_dtype(device)

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=amp_dtype,
        local_files_only=True,
        low_cpu_mem_usage=True,
    )

    if USE_GRAD_CHECKPOINT:
        base.gradient_checkpointing_enable()
        base.config.use_cache = False

    for p in base.parameters():
        p.requires_grad = False

    model = Qwen2VLClassifier(base, len(class_names), image_token_id).to(device)
    model.classifier = model.classifier.to(dtype=amp_dtype)

    train_loader = DataLoader(
        train_ds, batch_size=BATCH_SIZE, shuffle=True,
        num_workers=NUM_WORKERS,
        collate_fn=lambda b: collate_fn(b, processor)
    )
    val_loader = DataLoader(
        val_ds, batch_size=BATCH_SIZE,
        collate_fn=lambda b: collate_fn(b, processor)
    )
    test_loader = DataLoader(
        test_ds, batch_size=BATCH_SIZE,
        collate_fn=lambda b: collate_fn(b, processor)
    )

    optim = torch.optim.AdamW(
        model.classifier.parameters(),
        lr=LR_HEAD, weight_decay=WEIGHT_DECAY
    )

    total_steps = math.ceil(len(train_loader)/GRAD_ACCUM_STEPS)*NUM_EPOCHS
    sched = get_scheduler(optim, int(total_steps*WARMUP_RATIO), total_steps)

    scaler = torch.cuda.amp.GradScaler(enabled=(amp_dtype==torch.float16))

    best_val = 0.0

    for epoch in range(NUM_EPOCHS):
        model.train()
        optim.zero_grad(set_to_none=True)

        for it, batch in enumerate(tqdm(train_loader, desc=f"Epoch {epoch+1}")):
            labels = batch.pop("labels_cls").to(device)
            batch = {k: v.to(device) for k, v in batch.items()}

            with torch.cuda.amp.autocast(dtype=amp_dtype, enabled=device.type=="cuda"):
                logits = model(**batch)
                loss = F.cross_entropy(logits, labels, label_smoothing=0.1)

            loss = loss / GRAD_ACCUM_STEPS
            scaler.scale(loss).backward()

            if (it+1) % GRAD_ACCUM_STEPS == 0:
                scaler.step(optim)
                scaler.update()
                sched.step()
                optim.zero_grad(set_to_none=True)

        val_acc, val_f1, _, _ = evaluate(model, val_loader, device, amp_dtype)
        print(f"[Epoch {epoch+1}] Val Acc={val_acc:.4f}, Macro-F1={val_f1:.4f}")

        if val_acc > best_val:
            best_val = val_acc
            torch.save(model.state_dict(), os.path.join(OUT_DIR, "best.pt"))

    model.load_state_dict(torch.load(os.path.join(OUT_DIR, "best.pt")))
    test_acc, test_f1, y, p = evaluate(model, test_loader, device, amp_dtype)

    print(f"🎯 Test Acc={test_acc:.4f}, Macro-F1={test_f1:.4f}")

    with open(os.path.join(OUT_DIR, "summary.json"), "w") as f:
        json.dump({"test_acc": test_acc, "test_f1_macro": test_f1}, f, indent=2)


if __name__ == "__main__":
    main()
