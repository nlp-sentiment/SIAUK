import os
import math
import json
import random
from typing import List, Tuple, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from PIL import Image
from tqdm import tqdm

from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration

from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt


# =========================
# Config
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"

DATA_ROOT = "/gemini/code/images_fer_80_224"
TRAIN_DIR = os.path.join(DATA_ROOT, "Training")
VAL_DIR   = os.path.join(DATA_ROOT, "PublicTest")
TEST_DIR  = os.path.join(DATA_ROOT, "PrivateTest")

OUT_DIR = "/gemini/code/outputs/qwen2vl_cls_no_lora"
os.makedirs(OUT_DIR, exist_ok=True)

SEED = 42

NUM_EPOCHS = 5
BATCH_SIZE = 1
GRAD_ACCUM_STEPS = 8
NUM_WORKERS = 2

LR_HEAD = 1e-4
WEIGHT_DECAY = 0.01
WARMUP_RATIO = 0.03

MAX_TEXT_LEN = 128
PRINT_EVERY = 50

USE_AMP = True
USE_GRAD_CHECKPOINT = True
CLIP_GRAD_NORM = 1.0

PROMPT_TEMPLATE = (
    "<|image_pad|> This is a facial expression recognition task.\n\n"
    "Carefully analyze the person's facial muscles and visual cues, including:\n"
    "- Eyes (openness, tension, gaze)\n"
    "- Eyebrows (raised, lowered, furrowed)\n"
    "- Mouth and lips (smile, frown, openness)\n"
    "- Cheeks and nasolabial area\n\n"
    "You may reason using Facial Action Units (AUs), for example:\n"
    "- AU06 (cheek raiser)\n"
    "- AU12 (lip corner puller)\n"
    "- AU04 (brow lowerer)\n"
    "- AU01/02 (inner/outer brow raiser)\n"
    "- AU15 (lip corner depressor)\n\n"
    "Based on these visual signals, determine the most appropriate emotion.\n\n"
    "The possible emotion labels are: {labels}.\n\n"
    "Answer with only ONE emotion label from the list above."
)


# =========================
# Utils
# =========================
def set_seed(seed: int):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def list_images_and_labels(root_dir: str):
    class_names = sorted(d for d in os.listdir(root_dir) if not d.startswith("."))
    class_to_idx = {c: i for i, c in enumerate(class_names)}
    paths, labels = [], []
    for c in class_names:
        for fn in os.listdir(os.path.join(root_dir, c)):
            if fn.lower().endswith((".jpg", ".png", ".jpeg")):
                paths.append(os.path.join(root_dir, c, fn))
                labels.append(class_to_idx[c])
    return paths, labels, class_names


class FERFolderDataset(Dataset):
    def __init__(self, root_dir, expected_classes=None):
        self.paths, self.labels, self.class_names = list_images_and_labels(root_dir)
        if expected_classes is not None:
            assert self.class_names == expected_classes
        print(f"📊 Loaded {len(self.paths)} samples from {root_dir}")

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        img = Image.open(self.paths[idx]).convert("RGB")
        return img, self.labels[idx]


def collate_fn(batch, processor, class_names):
    images, labels = zip(*batch)
    labels = torch.tensor(labels, dtype=torch.long)

    prompt = PROMPT_TEMPLATE.format(labels=", ".join(class_names))
    texts = [prompt] * len(images)

    inputs = processor(
        text=texts,
        images=list(images),
        padding=True,
        truncation=True,
        max_length=MAX_TEXT_LEN,
        return_tensors="pt",
    )
    inputs["labels_cls"] = labels
    return inputs


def get_scheduler(optimizer, warmup, total):
    def lr_lambda(step):
        if step < warmup:
            return step / max(1, warmup)
        return max(0.0, (total - step) / max(1, total - warmup))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# =========================
# Model
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base, num_classes, image_token_id):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id
        self.classifier = nn.Linear(base.config.hidden_size, num_classes)

    def forward(self, **kwargs):
        labels = kwargs.pop("labels_cls", None)
        out = self.base(**kwargs, output_hidden_states=True, return_dict=True)
        h = out.hidden_states[-1]
        ids = kwargs["input_ids"]

        mask = (ids == self.image_token_id).unsqueeze(-1)
        pooled = (h * mask).sum(1) / mask.sum(1).clamp(min=1)

        logits = self.classifier(pooled)
        if labels is None:
            return logits
        return logits, F.cross_entropy(logits, labels)


# =========================
# Main
# =========================
def main():
    set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_ds = FERFolderDataset(TRAIN_DIR)
    val_ds = FERFolderDataset(VAL_DIR, train_ds.class_names)
    test_ds = FERFolderDataset(TEST_DIR, train_ds.class_names)

    processor = Qwen2VLProcessor.from_pretrained(MODEL_PATH, local_files_only=True)
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.bfloat16 if USE_AMP else torch.float32,
        local_files_only=True,
        low_cpu_mem_usage=True,
    )

    if USE_GRAD_CHECKPOINT:
        base.gradient_checkpointing_enable()
        base.config.use_cache = False

    for p in base.parameters():
        p.requires_grad = False

    model = Qwen2VLClassifier(base, len(train_ds.class_names), image_token_id).to(device)

    optimizer = torch.optim.AdamW(
        model.classifier.parameters(),
        lr=LR_HEAD,
        weight_decay=WEIGHT_DECAY,
    )

    train_loader = DataLoader(
        train_ds, BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS,
        collate_fn=lambda b: collate_fn(b, processor, train_ds.class_names)
    )

    total_steps = len(train_loader) * NUM_EPOCHS // GRAD_ACCUM_STEPS
    scheduler = get_scheduler(optimizer, int(total_steps * WARMUP_RATIO), total_steps)

    scaler = torch.cuda.amp.GradScaler(enabled=USE_AMP)

    for epoch in range(NUM_EPOCHS):
        model.train()
        optimizer.zero_grad()
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{NUM_EPOCHS}")

        for it, batch in enumerate(pbar):
            labels = batch.pop("labels_cls").to(device)
            batch = {k: v.to(device) for k, v in batch.items()}

            with torch.cuda.amp.autocast(enabled=USE_AMP):
                logits = model(**batch)
                loss = F.cross_entropy(logits, labels, label_smoothing=0.1)

            loss = loss / GRAD_ACCUM_STEPS
            scaler.scale(loss).backward()

            if (it + 1) % GRAD_ACCUM_STEPS == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()
                scheduler.step()

    print("✅ No-LoRA training finished successfully.")


if __name__ == "__main__":
    main()
