import os
import json
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image

from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration
from peft import LoraConfig, get_peft_model

from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import numpy as np


# =========================
# Config
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"
DATA_ROOT = "/gemini/code/CK+_SI_801010"
VAL_DIR   = os.path.join(DATA_ROOT, "PublicTest")
TEST_DIR  = os.path.join(DATA_ROOT, "PrivateTest")

OUT_DIR = "/gemini/code/outputs/qwen2vl_ckplus_final"
os.makedirs(OUT_DIR, exist_ok=True)

CKPT_PATH = os.path.join(OUT_DIR, "best.pt")

DEVICE = torch.device("cuda")
DTYPE = torch.bfloat16
BATCH_SIZE = 4

LORA_R = 8
LORA_ALPHA = 16
LORA_DROPOUT = 0.05
LORA_TARGET_MODULES = ["q_proj", "k_proj"]	

PROMPT_TEMPLATE = (
    "<|image_pad|> This is a facial expression recognition task.\n\n"
    "The possible emotion labels are: {labels}.\n\n"
    "Answer with only ONE emotion label from the list above."
)


# =========================
# Dataset
# =========================
def list_images_and_labels(root_dir):
    class_names = sorted(os.listdir(root_dir))
    class_to_idx = {c: i for i, c in enumerate(class_names)}
    paths, labels = [], []
    for c in class_names:
        for fn in os.listdir(os.path.join(root_dir, c)):
            if fn.lower().endswith((".png", ".jpg", ".jpeg")):
                paths.append(os.path.join(root_dir, c, fn))
                labels.append(class_to_idx[c])
    return paths, labels, class_names


class FERDataset(Dataset):
    def __init__(self, root_dir, expected_classes=None):
        self.paths, self.labels, self.class_names = list_images_and_labels(root_dir)
        if expected_classes is not None:
            assert self.class_names == expected_classes

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        return Image.open(self.paths[idx]).convert("RGB"), self.labels[idx]


def collate_fn(batch, processor, class_names):
    images = [b[0] for b in batch]
    labels = torch.tensor([b[1] for b in batch], dtype=torch.long)
    prompt = PROMPT_TEMPLATE.format(labels=", ".join(class_names))
    inputs = processor(
        text=[prompt] * len(images),
        images=images,
        padding=True,
        return_tensors="pt",
    )
    inputs["labels_cls"] = labels
    return inputs


# =========================
# Model
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base, num_classes, image_token_id):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id
        self.classifier = nn.Linear(base.config.hidden_size, num_classes)

    def forward(self, **inputs):
        out = self.base(**inputs, output_hidden_states=True, return_dict=True)
        h = out.hidden_states[-1]
        img_mask = (inputs["input_ids"] == self.image_token_id).unsqueeze(-1)
        pooled = (h * img_mask).sum(1) / img_mask.sum(1).clamp(min=1.0)
        return self.classifier(pooled)


@torch.no_grad()
def evaluate(model, loader):
    ys, ps = [], []
    for batch in loader:
        labels = batch.pop("labels_cls").to(DEVICE)
        batch = {k: v.to(DEVICE) for k, v in batch.items()}
        preds = model(**batch).argmax(-1)
        ys.extend(labels.cpu().tolist())
        ps.extend(preds.cpu().tolist())
    return ys, ps


def plot_confusion_matrix(y, p, class_names, path, title):
    cm = confusion_matrix(y, p, labels=list(range(len(class_names))))
    plt.figure(figsize=(7, 6))
    plt.imshow(cm, cmap="Blues")
    plt.title(title)
    plt.colorbar()
    plt.xticks(range(len(class_names)), class_names, rotation=45)
    plt.yticks(range(len(class_names)), class_names)
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            plt.text(j, i, cm[i, j], ha="center", va="center")
    plt.tight_layout()
    plt.savefig(path, dpi=200)
    plt.close()


# =========================
# Main
# =========================
def main():
    print("🚀 Fast Eval on 40GB GPU")
    torch.cuda.empty_cache()

    val_ds = FERDataset(VAL_DIR)
    class_names = val_ds.class_names
    test_ds = FERDataset(TEST_DIR, expected_classes=class_names)

    processor = Qwen2VLProcessor.from_pretrained(MODEL_PATH, local_files_only=True)
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    val_loader = DataLoader(val_ds, BATCH_SIZE, shuffle=False,
                            collate_fn=lambda b: collate_fn(b, processor, class_names))
    test_loader = DataLoader(test_ds, BATCH_SIZE, shuffle=False,
                             collate_fn=lambda b: collate_fn(b, processor, class_names))

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH, torch_dtype=DTYPE, local_files_only=True
    )
    base = get_peft_model(base, LoraConfig(
        r=LORA_R, lora_alpha=LORA_ALPHA, lora_dropout=LORA_DROPOUT,
        target_modules=LORA_TARGET_MODULES, task_type="CAUSAL_LM"
    ))

    model = Qwen2VLClassifier(base, len(class_names), image_token_id).to(DEVICE)
    model.load_state_dict(torch.load(CKPT_PATH, map_location=DEVICE))
    model.eval()

    vy, vp = evaluate(model, val_loader)
    ty, tp = evaluate(model, test_loader)

    plot_confusion_matrix(vy, vp, class_names,
                          os.path.join(OUT_DIR, "confusion_val.png"),
                          "Confusion Matrix (Validation)")
    plot_confusion_matrix(ty, tp, class_names,
                          os.path.join(OUT_DIR, "confusion_test.png"),
                          "Confusion Matrix (Test)")

    report = classification_report(
        ty, tp,
        labels=list(range(len(class_names))),
        target_names=class_names,
        digits=4,
        zero_division=0
    )
    with open(os.path.join(OUT_DIR, "classification_report_test.txt"), "w") as f:
        f.write(report)

    summary = {
        "val_acc": accuracy_score(vy, vp),
        "test_acc": accuracy_score(ty, tp),
        "val_f1_macro": f1_score(vy, vp, average="macro"),
        "test_f1_macro": f1_score(ty, tp, average="macro"),
        "classes": class_names,
        "checkpoint": CKPT_PATH
    }
    with open(os.path.join(OUT_DIR, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("✅ All results generated successfully.")


if __name__ == "__main__":
    main()
