import os
import json
import random
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from PIL import Image

from transformers import Qwen2VLProcessor, Qwen2VLForConditionalGeneration

from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt


# =========================
# Config（CK+ Final | No-LoRA | No-Instruction）
# =========================
MODEL_PATH = "/gemini/pretrain/Qwen2-VL-7B-Instruct"

DATA_ROOT = "/gemini/code/CK+_SI_801010"
TRAIN_DIR = os.path.join(DATA_ROOT, "Training")
VAL_DIR   = os.path.join(DATA_ROOT, "PublicTest")
TEST_DIR  = os.path.join(DATA_ROOT, "PrivateTest")

OUT_DIR = "/gemini/code/outputs/qwen2vl_ckplus_final"
os.makedirs(OUT_DIR, exist_ok=True)

SEED = 42
NUM_EPOCHS = 20
BATCH_SIZE = 1
GRAD_ACCUM_STEPS = 8

LR_HEAD = 1e-4
CLIP_GRAD_NORM = 1.0
USE_GRAD_CHECKPOINT = True

# 🚫 无指令：只保留 image token
PROMPT_TEMPLATE = "<|image_pad|>"


# =========================
# Utils
# =========================
def set_seed(seed: int):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def list_images_and_labels(root_dir: str) -> Tuple[List[str], List[int], List[str]]:
    class_names = sorted(os.listdir(root_dir))
    class_to_idx = {c: i for i, c in enumerate(class_names)}
    paths, labels = [], []
    for c in class_names:
        for fn in os.listdir(os.path.join(root_dir, c)):
            if fn.lower().endswith((".png", ".jpg", ".jpeg")):
                paths.append(os.path.join(root_dir, c, fn))
                labels.append(class_to_idx[c])
    return paths, labels, class_names


class FERDataset(Dataset):
    def __init__(self, root_dir: str, expected_classes=None):
        self.paths, self.labels, self.class_names = list_images_and_labels(root_dir)
        if expected_classes is not None:
            assert self.class_names == expected_classes

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        img = Image.open(self.paths[idx]).convert("RGB")
        return img, self.labels[idx]


def collate_fn(batch, processor):
    images = [b[0] for b in batch]
    labels = torch.tensor([b[1] for b in batch], dtype=torch.long)

    inputs = processor(
        text=[PROMPT_TEMPLATE] * len(images),
        images=images,
        padding=True,
        return_tensors="pt",
    )
    inputs["labels_cls"] = labels
    return inputs


# =========================
# Model（Visual-token mean pooling）
# =========================
class Qwen2VLClassifier(nn.Module):
    def __init__(self, base, num_classes, image_token_id):
        super().__init__()
        self.base = base
        self.image_token_id = image_token_id
        self.classifier = nn.Linear(base.config.hidden_size, num_classes)

    def forward(self, labels_cls=None, **inputs):
        out = self.base(**inputs, output_hidden_states=True, return_dict=True)
        h = out.hidden_states[-1]  # [B, T, H]

        input_ids = inputs["input_ids"]
        img_mask = (input_ids == self.image_token_id).unsqueeze(-1)

        pooled = (h * img_mask).sum(dim=1) / img_mask.sum(dim=1).clamp(min=1.0)
        logits = self.classifier(pooled)

        if labels_cls is None:
            return logits
        loss = F.cross_entropy(logits, labels_cls)
        return logits, loss


@torch.no_grad()
def evaluate_with_outputs(model, loader, device):
    model.eval()
    ys, ps = [], []

    for batch in loader:
        labels = batch.pop("labels_cls").to(device)
        batch = {k: v.to(device) for k, v in batch.items()}
        preds = model(**batch).argmax(dim=-1)

        ys.extend(labels.cpu().tolist())
        ps.extend(preds.cpu().tolist())

    return (
        accuracy_score(ys, ps),
        f1_score(ys, ps, average="macro"),
        ys,
        ps,
    )


def plot_confusion_matrix(y, p, class_names, path, title):
    cm = confusion_matrix(y, p)
    plt.figure(figsize=(8, 6))
    plt.imshow(cm, cmap="Blues")
    plt.title(title)
    plt.colorbar()
    plt.xticks(range(len(class_names)), class_names, rotation=45, ha="right")
    plt.yticks(range(len(class_names)), class_names)
    plt.tight_layout()
    plt.savefig(path, dpi=200)
    plt.close()


# =========================
# Main
# =========================
def main():
    set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_ds = FERDataset(TRAIN_DIR)
    class_names = train_ds.class_names
    val_ds = FERDataset(VAL_DIR, class_names)
    test_ds = FERDataset(TEST_DIR, class_names)

    processor = Qwen2VLProcessor.from_pretrained(MODEL_PATH, local_files_only=True)
    image_token_id = processor.tokenizer.convert_tokens_to_ids("<|image_pad|>")

    base = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.bfloat16,
        local_files_only=True,
    )

    if USE_GRAD_CHECKPOINT:
        base.gradient_checkpointing_enable()
        base.config.use_cache = False

    # 🔒 冻结 backbone
    for p in base.parameters():
        p.requires_grad = False

    model = Qwen2VLClassifier(base, len(class_names), image_token_id).to(device)

    train_loader = DataLoader(
        train_ds, BATCH_SIZE, shuffle=True,
        collate_fn=lambda b: collate_fn(b, processor)
    )
    val_loader = DataLoader(
        val_ds, BATCH_SIZE, shuffle=False,
        collate_fn=lambda b: collate_fn(b, processor)
    )
    test_loader = DataLoader(
        test_ds, BATCH_SIZE, shuffle=False,
        collate_fn=lambda b: collate_fn(b, processor)
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=LR_HEAD)
    best_val_acc = -1.0
    best_path = os.path.join(OUT_DIR, "best.pt")

    # ===== Training =====
    for epoch in range(NUM_EPOCHS):
        model.train()
        optimizer.zero_grad()

        for step, batch in enumerate(train_loader):
            labels = batch.pop("labels_cls").to(device)
            batch = {k: v.to(device) for k, v in batch.items()}

            _, loss = model(labels_cls=labels, **batch)
            loss = loss / GRAD_ACCUM_STEPS
            loss.backward()

            if (step + 1) % GRAD_ACCUM_STEPS == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), CLIP_GRAD_NORM)
                optimizer.step()
                optimizer.zero_grad()

        val_acc, _, _, _ = evaluate_with_outputs(model, val_loader, device)
        print(f"Epoch {epoch+1}: val_acc={val_acc:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), best_path)

    # ===== Final Eval =====
    model.load_state_dict(torch.load(best_path, map_location=device))

    val_acc, val_f1, vy, vp = evaluate_with_outputs(model, val_loader, device)
    test_acc, test_f1, ty, tp = evaluate_with_outputs(model, test_loader, device)

    plot_confusion_matrix(vy, vp, class_names, os.path.join(OUT_DIR, "confusion_val.png"), "Val Confusion")
    plot_confusion_matrix(ty, tp, class_names, os.path.join(OUT_DIR, "confusion_test.png"), "Test Confusion")

    with open(os.path.join(OUT_DIR, "classification_report_test.txt"), "w") as f:
        f.write(classification_report(ty, tp, target_names=class_names, digits=4))

    with open(os.path.join(OUT_DIR, "summary.json"), "w") as f:
        json.dump({
            "val_acc": val_acc,
            "test_acc": test_acc,
            "test_f1_macro": test_f1,
            "finetune_type": "no_lora_no_instruction"
        }, f, indent=2, ensure_ascii=False)

    print("\n✅ No-LoRA + No-Instruction experiment completed.")


if __name__ == "__main__":
    main()
